---
name: sermon-producer
description: An agent that automates the creation of a sermon media package, including a slideshow presentation and a short podcast audio overview, from a raw Fireflies.ai sermon transcript. Use this skill to streamline the entire production workflow from transcript to final deliverables.
---

# Sermon Producer

This skill provides a complete, automated workflow for transforming a raw sermon transcript from Fireflies.ai into a polished media package, including a slideshow presentation and a podcast audio episode, consistent with the Chukwuma Theology brand.

## Workflow

To create a sermon media package, follow these steps precisely.

### 1. Transcript Preparation

1.  **Receive the Transcript:** The user will provide a raw text transcript, typically from Fireflies.ai.
2.  **Clean the Transcript:** Use the bundled Python script to remove timestamps, speaker labels, and other transcription artifacts.
    ```bash
    python /home/ubuntu/skills/sermon-producer/scripts/clean_transcript.py <input_transcript_path> /home/ubuntu/cleaned_sermon.txt
    ```

### 2. Content Analysis and Structuring

1.  **Analyze the Sermon:** Read the `cleaned_sermon.txt` file to identify the core components of the sermon:
    *   The main title and subtitle/theme.
    *   The central narrative hook or opening story.
    *   The primary theological problem or question being addressed.
    *   The key biblical principles, passages, and arguments used.
    *   Any practical methods or steps offered (e.g., the PREACH method).
    *   The resolution or climax of the sermon narrative.
    *   Any closing poem, quote, or summary.
2.  **Generate Slide Content Outline:** Use the `/home/ubuntu/skills/sermon-producer/templates/slide_outline_template.md` to create a comprehensive slide-by-slide content plan. Save this as `/home/ubuntu/slide_content_plan.md`.
3.  **Generate Podcast Script:** Use the `/home/ubuntu/skills/sermon-producer/templates/podcast_script_template.md` to create a condensed, narrative podcast script. Save this as `/home/ubuntu/podcast_script.md`.

### 3. Media Production

1.  **Retrieve Style Guidelines:** Read the `/home/ubuntu/skills/sermon-producer/references/style_guide.md` to get the exact `style_instruction` object for the slideshow and the voice/tone guidelines for the podcast.
2.  **Generate Slideshow:**
    *   Use the `slide_initialize` tool to create the presentation project.
    *   Use the `style_instruction` from the style guide.
    *   Use the `slide_content_plan.md` to define the `outline`.
    *   Generate each slide image using `image_slide_generate`, ensuring visual continuity by referencing the previous slide.
3.  **Generate Podcast Audio:**
    *   Read the final `/home/ubuntu/podcast_script.md`.
    *   Use the `generate_speech` tool to create the audio file, applying the voice and tone guidelines from the style guide.
    *   Save the audio as `/home/ubuntu/sermon_podcast.wav`.

### 4. Final Delivery

1.  **Present the Slideshow:** Use the `slide_present` tool to prepare the final presentation for the user.
2.  **Package and Deliver:** Send a final message to the user, attaching:
    *   The presented slideshow (`manus-slides://...`).
    *   The final podcast audio file (`/home/ubuntu/sermon_podcast.wav`).
    *   The slide content plan (`/home/ubuntu/slide_content_plan.md`).
    *   The podcast script (`/home/ubuntu/podcast_script.md`).

## Bundled Resources

*   **`scripts/clean_transcript.py`**: A Python script to automatically clean raw Fireflies.ai transcripts.
*   **`references/style_guide.md`**: Defines the standard visual and audio identity for all sermon productions.
*   **`templates/slide_outline_template.md`**: A template for structuring the sermon into a slide-by-slide content plan.
*   **`templates/podcast_script_template.md`**: A template for drafting the condensed podcast script.
