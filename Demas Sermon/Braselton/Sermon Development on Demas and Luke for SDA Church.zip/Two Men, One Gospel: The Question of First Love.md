# Two Men, One Gospel: The Question of First Love
**Draft Sermon for Braselton Seventh-day Adventist Church**
**By Chukwuma Onyeije, MD**
*(Target Length: 30 Minutes)*

## Introduction

Picture the scene. It is Rome, and the Apostle Paul is in the Mamertine Prison. This is not house arrest. It is a cold, damp cell. Execution is approaching. Paul is writing his final letter to Timothy, and in the closing verses, he takes attendance.

Listen to 2 Timothy 4:10-11:
> *"For Demas hath forsaken me, having loved this present world, and is departed unto Thessalonica... Only Luke is with me."*

Two names. Demas and Luke. Both stood in the same room, heard the same gospel, and faced the same world pulling at them. One drifted. One stayed. The difference was not talent or theological knowledge. It was the location of their love.

This is not a story about dramatic apostasy. It is a story about the slow, unannounced migration of the heart from Christ to comfort.

## I. The Drift of Demas

Demas was an insider. In Philemon 1:24, Paul calls him a "fellow labourer." In Colossians 4:14, he is named alongside Luke. He was present and working.

But then comes 2 Timothy 4:10: *"For Demas hath forsaken me, having loved this present world."*

The Greek word Paul uses is *agapēsas*. It is the same root word used in John 3:16. Paul does not say Demas feared the world or was distracted by it. He *loved* it. He gave to the present age the affection that belongs to God.

He loved *ton nun aiōna*—this present age. He embraced the world's way of measuring worth, security, and meaning.

Ellen G. White writes in *The Acts of the Apostles* (p. 455):
> "For worldly gain, Demas bartered every high and noble consideration. How shortsighted the exchange! Possessing only worldly wealth or honor, Demas was poor indeed..."

This was a chronic condition of the soul. Demas stayed near the work, but drifted from the heart of the work.

## II. The Diagnosis

How does a faithful laborer become a Demas?

**1. Urgency Becomes Background Music**
When Demas first heard the gospel, he likely felt the urgency of the Second Coming. But slowly, the world stopped feeling temporary. When did you last feel the urgency of the gospel?

**2. Good Work Replaces First Love**
Demas was productive while he drifted. In Revelation 2:4, Jesus tells the hardworking church at Ephesus: *"Nevertheless I have somewhat against thee, because thou hast left thy first love."*

We can be so busy doing the work of the Lord that we forget the Lord of the work. As Ellen White notes in *Testimonies for the Church*, Vol. 5 (p. 161):
> "Many are so absorbed in business that they have no time for prayer... The cares of this life crowd out the things of eternity."

**3. The Love Question**
Jesus asked Peter three times: *"Lovest thou me?"* (John 21). The issue is always love. What would you struggle to surrender if Christ asked for it this week?

## III. The Faithfulness of Luke

If Demas is the warning, Luke is the hope. *"Only Luke is with me."*

Luke was a physician with options. He could have found a comfortable life far from a condemned prisoner. But he chose the prison cell. Why?

**1. He Wrote Himself Out of the Story**
In the Book of Acts, Luke says "we," but never inserts his name. He subordinated himself to the gospel.

**2. He Practiced What He Documented**
Luke recorded Jesus saying, "take up his cross daily" (Luke 9:23). And he lived it.

**3. He Carried the "Only"**
*"Only Luke."* One man's faithfulness became the entire presence of the body of Christ for Paul. You never know when your staying will be someone's *only*.

Ellen White says (*The Acts of the Apostles*, p. 490):
> "The services of Luke, the beloved disciple and faithful friend, were a great comfort to Paul..."

## IV. The Interior Turn

I am a physician. I build things. I move fast. And sometimes, in the volume of good work, I feel the pull. It is the satisfaction of a highly productive week that had very little room for the presence of God.

That is the Demas condition. We are all on this trajectory. The question is: What do I love most?

## Conclusion

The Laodicean church was comfortable and lukewarm (Rev 3). But Jesus offers an invitation: **Remember, Repent, Return** (Rev 2:5).

Christ does not say, "Work harder." He says, "Love Me first."

As Ellen White reminds us (*Steps to Christ*, p. 44):
> "They behold the Saviour's matchless love… and to them duty becomes a delight and sacrifice a pleasure."

You will leave this building today and return to this present age. Which man are you becoming?

Luke stayed. And so can you. Not in your own strength, but in the strength of the One who stayed for you. Go, and love Him first.

---

### References
[1] White, E. G. (1911). *The Acts of the Apostles*, p. 455.
[2] White, E. G. (1911). *The Acts of the Apostles*, p. 490.
[3] White, E. G. (1882). *Testimonies for the Church, Vol. 5*, p. 161.
[4] White, E. G. (1892). *Steps to Christ*, p. 44.
