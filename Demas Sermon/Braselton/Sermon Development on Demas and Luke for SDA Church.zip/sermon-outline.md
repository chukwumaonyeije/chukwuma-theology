_This is an executable example of a sermon outline created with the `chukwuma-theology` skill._

# Sermon Outline: [Sermon Title]

**Text:** [Main Bible Passage]

**Thesis:** [A single, clear sentence that summarizes the main point of the sermon.]

**Introduction (5 minutes)**

*   **Hook:** [Start with a compelling story, a surprising statistic, a relatable experience, or a provocative question to grab the audience's attention.]
*   **Introduce the Problem/Tension:** [Briefly describe the problem, need, or question that the sermon will address. Connect it to the lives of the listeners.]
*   **Introduce the Text:** [Introduce the main Bible passage for the sermon.]
*   **State the Thesis:** [Clearly state the sermon's main point.]
*   **Roadmap:** [Briefly outline the main points of the sermon.]

**Point 1: [First Main Point] (10 minutes)**

*   **Explanation:** [Explain the first main point from the text. Use historical and cultural context to help the audience understand the passage.]
*   **Illustration:** [Use a story, analogy, or example to illustrate the point and make it memorable.]
*   **Application:** [Explain how this point applies to the lives of the listeners. What should they think, feel, or do in response?]

**Point 2: [Second Main Point] (10 minutes)**

*   **Explanation:** [Explain the second main point from the text.]
*   **Illustration:** [Use a story, analogy, or example to illustrate the point.]
*   **Application:** [Explain how this point applies to the lives of the listeners.]

**Point 3: [Third Main Point] (10 minutes)**

*   **Explanation:** [Explain the third main point from the text.]
*   **Illustration:** [Use a story, analogy, or example to illustrate the point.]
*   **Application:** [Explain how this point applies to the lives of the listeners.]

**Conclusion (5 minutes)**

*   **Summarize Main Points:** [Briefly restate the main points of the sermon.]
*   **Restate Thesis:** [Restate the sermon's main point in a fresh and compelling way.]
*   **Call to Action:** [Challenge the audience to respond to the message. This could be a call to repentance, faith, obedience, or a specific action.]
*   **Closing Prayer/Blessing:** [End with a prayer or blessing that reinforces the sermon's message.]
