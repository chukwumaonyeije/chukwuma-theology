# Sermon Media Style Guide

This document defines the standard visual and audio identity for all sermon productions created with the `sermon-producer` skill. Adhere to these guidelines to ensure brand consistency.

## Slideshow Visual Identity

When using the `slide_initialize` tool, use the following `style_instruction` object without modification.

```python
style_instruction = {
    "aesthetic_direction": "Deeply atmospheric and reverent, blending warm, earthy textures with soft, divine light to evoke healing, restoration, and sacred weight.",
    "color_palette": "#2C3E50, #E67E22, #ECF0F1, #95A5A6",
    "typography": "Playfair Display, Lato"
}
```

## Podcast Audio Identity

When using the `generate_speech` tool, use the following voice and delivery style:

- **Voice:** `female_voice`
- **Tone & Delivery:** A professional female voice that is chatty but authoritative. The delivery should be warm, engaging, and reflective, suitable for a theological podcast format that blends storytelling, theology, and practical application.
