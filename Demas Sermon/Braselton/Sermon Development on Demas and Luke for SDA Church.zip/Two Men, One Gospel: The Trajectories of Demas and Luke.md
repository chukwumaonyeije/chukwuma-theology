# Two Men, One Gospel: The Trajectories of Demas and Luke
**A Sermon for Braselton Seventh-day Adventist Church**
**By Chukwuma Onyeije, MD**

## Introduction: The Final Dispatch

Imagine the scene. It is Rome. The Mamertine Prison. This is not Paul’s first imprisonment, where he enjoyed the relative comfort of a rented house and the freedom to receive guests. This is the second imprisonment under Nero. The air is cold, the stone is damp, and the shadow of the executioner’s block is long. Paul knows his time is short. He is writing what will become his final letter—his last will and testament to his young protégé, Timothy.

In the closing verses of this letter, 2 Timothy chapter 4, Paul takes attendance. He gives a roll call of those who have been with him. And in the span of two short verses, he records a tragedy and a triumph that should arrest the attention of every Christian living in this modern age.

Listen to the words of 2 Timothy 4:10-11:
> *"For Demas hath forsaken me, having loved this present world, and is departed unto Thessalonica; Crescens to Galatia, Titus unto Dalmatia. Only Luke is with me."*

Two names. Demas and Luke. Both men stood in the same room. Both men heard the same gospel from the lips of the greatest apostle who ever lived. Both men served the same mission, faced the same pressures, and felt the same world pulling at them. Yet, one stayed, and the other drifted. One is remembered by the word "forsaken." The other is remembered by the word "only."

The difference between these two men was not talent. It was not theological knowledge. It was not even outward faithfulness in the beginning. The difference was the location of their love.

Today, we are not looking at a story of dramatic apostasy or sudden rebellion. No one in this room is likely to wake up tomorrow and publicly renounce their faith. But we are looking at something far more subtle and far more dangerous: the slow, unannounced migration of the heart from Christ to comfort. We are looking at the condition of Demas.

## I. The Arc of Demas: A Chronic Condition

To understand the tragedy of Demas, we must trace his trajectory. Demas was not an outsider who briefly flirted with Christianity. He was an insider. He was part of Paul’s inner circle.

In Philemon 1:24, Paul lists him among his most trusted companions: *"Marcus, Aristarchus, Demas, Lucas, my fellow labourers."* Demas was a laborer. He was working. He was sweating for the gospel.

In Colossians 4:14, written during Paul’s first Roman imprisonment, we read: *"Luke, the beloved physician, and Demas, greet you."* He is named right alongside Luke. There is no warning sign, no asterisk next to his name. He is present and accounted for.

But then comes the final mention in 2 Timothy 4:10: *"For Demas hath forsaken me, having loved this present world."*

What happened? The Greek language here is precise and devastating. Paul uses the word *agapēsas*. It is the aorist active participle of *agapaō*. This is the same root word used in John 3:16: *"For God so loved the world."* It is the same word used in the Great Commandment: *"Thou shalt love the Lord thy God."*

Paul does not say that Demas feared the world. He does not say that Demas admired the world, or occasionally enjoyed the world, or was simply distracted by the world. He says Demas *loved* it. He took the deepest affection of his soul—the affection that properly belongs to God alone—and he gave it to the present age.

The text says he loved "this present world"—in Greek, *ton nun aiōna*. The *aiōn* is not just geography or physical pleasure. It refers to the entire system of values, allegiances, and assumptions belonging to this era before Christ’s return. It is the world as a rival ordering of reality. It is the pursuit of security, status, wealth, and comfort over the call of the cross.

Demas did not necessarily become a wicked man in the eyes of society. He probably went to Thessalonica, set up a business, lived a respectable life, and maybe even attended the local synagogue. But he embraced the *aiōn*. He traded eternal riches for temporary safety.

Ellen G. White, in *The Acts of the Apostles* (p. 455), captures this tragedy perfectly:
> "Demas, who for a time had been a fellow laborer with the apostle, afterward forsook the cause of Christ. Of him Paul wrote: 'Demas hath forsaken me, having loved this present world.' For worldly gain, Demas bartered every high and noble consideration. How shortsighted the exchange! Possessing only worldly wealth or honor, Demas was poor indeed, however much he might proudly call his own."

This was not an acute collapse. This was a chronic condition of the soul. Demas stayed near the work, but he drifted from the heart of the work.

## II. The Diagnosis: When Good Work Replaces First Love

Most of us in this room are not Demas yet. But none of us are automatically Luke, either. The trajectory—not the position—is what matters. How does a faithful laborer become a Demas?

### 1. The Drift from Urgency to Heritage
When Demas first heard Paul preach, he likely felt the burning urgency of the Second Coming. He believed the present world was passing away. But somewhere along the line, *soon* became background music. The world stopped feeling temporary and started feeling permanent.

For many of us, especially those of us who have grown up in the church or have achieved professional success, the urgency of the gospel can slowly fade into a comfortable heritage. We build our careers, we secure our futures, and the return of Christ becomes a theological doctrine rather than a daily anticipation. When did you last feel the urgency you felt the first time you understood what the gospel actually meant?

### 2. The Substitution of Good Work for First Love
Here is what is so subtle about Demas: he was productive while he drifted.

In Revelation 2, Jesus addresses the church at Ephesus. He commends their hard work, their patience, and their doctrinal purity. But then He issues a devastating diagnosis in verse 4: *"Nevertheless I have somewhat against thee, because thou hast left thy first love."*

A church—or a Christian professional—can work harder than anyone else. We can serve on the board, teach Sabbath School, excel in our medical practices, and build our businesses. But if the heart has moved, the work is hollow. The most dangerous spiritual condition is not rebellion. It is comfortable productivity with a cold heart. We can be so busy doing the work of the Lord that we forget the Lord of the work.

As Ellen White notes in *Testimonies for the Church*, Vol. 5 (p. 161):
> "Many are so absorbed in business that they have no time for prayer, no time for the study of the Bible… The cares of this life crowd out the things of eternity."

### 3. The Love Question
In John 21, after Peter had denied Jesus, the resurrected Christ met him on the shore of the Sea of Galilee. Jesus did not ask Peter, "Will you work harder?" He did not ask, "Will you preach better sermons?" He asked one question, three times: *"Simon, son of Jonas, lovest thou me?"*

The issue is always love. Where your treasure is, there your heart will be also (Matthew 6:21). What would you struggle to surrender if Christ asked for it this week?

## III. The Anatomy of Fidelity: The Example of Luke

If Demas is the warning, Luke is the beacon of hope. In the damp cold of that Roman prison, Paul writes a sentence that lands with profound weight: *"Only Luke is with me."* (2 Timothy 4:11).

Luke was a physician. In the first-century Roman world, that meant education, options, and mobility. He was exactly the kind of person who had every reason to find a comfortable arrangement. He could have set up a lucrative practice in a safe city, far away from a condemned prisoner like Paul. But he chose the prison cell. Why?

### 1. He Wrote Himself Out of the Story
If you read the Gospel of Luke and the Book of Acts, you will notice something remarkable. Luke is present in the "we" passages of Acts—*"we sailed," "we stayed"*—but he never inserts his name. He was not building his own brand. He was documenting Someone else's story. This is the disposition that holds: not self-erasure, but self-subordination. He placed himself in proper relationship to Christ.

### 2. He Practiced What He Documented
Luke recorded the words of Jesus in Luke 9:23: *"If any man will come after me, let him deny himself, and take up his cross daily, and follow me."* Luke didn't just write those words; he lived them. He understood that following Christ meant embracing the cross, even when it meant staying with a man who was going to die.

### 3. He Carried the "Only"
*"Only Luke is with me."* Three words. One lifetime of faithfulness compressed. That word—*only*—is not a footnote. It is a pastoral testimony. One man's faithfulness became, in Paul's final hours, the embodiment of the entire body of Christ. You never know when your presence, your staying, will be someone's *only*.

Ellen White beautifully summarizes Luke's contribution (*The Acts of the Apostles*, p. 490):
> "The services of Luke, the beloved disciple and faithful friend, were a great comfort to Paul and enabled him to communicate with his brethren and the world without."

Luke subordinated his professional gifts to the gospel mission. He healed bodies, but he knew the soul's need was greater.

## IV. The Interior Turn: The Mirror of the Word

I cannot preach this sermon without standing under its conviction myself. I am a physician. I build things. I move fast. I teach, I write, I carry multiple responsibilities. And sometimes, in the sheer volume of that good work, I can feel the pull.

It is not a pull toward obvious, scandalous sin. It is a pull toward something quieter. It is the satisfaction of a highly productive week that had very little room for the presence of God. The theology remains correct. The schedule remains full. But the heart slowly moves.

That is the Demas condition. And if I am not careful, it is my condition.

We are all somewhere on this trajectory. The question is not whether we have felt the drift. The question is whether we are honest enough to stop, look at the compass of our souls, and ask: What do I love most? Am I becoming Demas, or am I becoming Luke?

## Conclusion: The Call to Return

The letter to the Laodicean church in Revelation 3 describes a people who are comfortable, wealthy, and lukewarm. But Jesus does not end His message to them with condemnation. He ends it with an invitation: *"I counsel thee to buy of me gold tried in the fire... and anoint thine eyes with eyesalve, that thou mayest see."* (Rev 3:18).

If you have felt the drift, if you realize that the love of this present world has begun to eclipse your love for Christ, the prescription is found in Revelation 2:5: **Remember, Repent, Return.**

Christ does not say, "Work harder." He says, "Love Me first."

As Ellen White reminds us in *Steps to Christ* (p. 44):
> "It is not so much the fear of punishment, or the hope of everlasting reward, that leads the disciples of Christ to follow Him. They behold the Saviour's matchless love… and to them duty becomes a delight and sacrifice a pleasure."

You will leave this building today and return to the *aiōn*—this present age. You will face the same pressures that Demas and Luke faced. You will make small, seemingly invisible choices this week that will determine which trajectory you are on.

But hear this good news: Luke stayed. And so can you. Not in your own strength. Not by your own willpower. But in the strength of the One who stayed for you. Jesus Christ did not forsake you. He endured the cross, despising the shame, because of His great love for you.

Go, and love Him first.

---

### References
[1] White, E. G. (1911). *The Acts of the Apostles*, p. 455.
[2] White, E. G. (1911). *The Acts of the Apostles*, p. 490.
[3] White, E. G. (1882). *Testimonies for the Church, Vol. 5*, p. 161.
[4] White, E. G. (1892). *Steps to Christ*, p. 44.
[5] White, E. G. (1903). *Education*, p. 57.
