# Podcast Script: "Two Men, One Gospel"
## Demas, Luke, and the Question of First Love
**Chukwuma Theology | Episode Runtime: ~8–10 minutes**

---

[INTRO MUSIC — warm, reflective piano, fading slowly]

Welcome back to Chukwuma Theology. I'm Dr. Chukwuma Onyeije — physician, elder, and a fellow traveler in this life of faith. Today, we're sitting with a sermon I've been preparing for the Braselton Seventh-day Adventist Church, and I want to walk you through the heart of it — because I believe it is a message that every one of us needs to hear, regardless of where we are on our spiritual journey.

The sermon is called **"Two Men, One Gospel."** And it is built on one of the most quietly devastating verses in all of the New Testament.

---

[PAUSE — slight music fade]

Picture the scene. It is Rome. The Mamertine Prison. The Apostle Paul is in his second and final imprisonment. This is not the comfortable house arrest of Acts 28, where he could receive guests and write letters in relative peace. This is a cold, damp cell. Execution is close. He is writing what will become his last letter — his final words to his beloved son in the faith, Timothy.

And in the closing verses of that letter, Paul takes attendance. He gives a roll call of those who have been with him. And in just two short verses — 2 Timothy 4:10 and 11 — he records both a tragedy and a triumph.

He writes: *"For Demas hath forsaken me, having loved this present world, and is departed unto Thessalonica... Only Luke is with me."*

Two names. Demas and Luke. Both were in Paul's inner circle. Both heard the same gospel. Both served the same mission. And yet — one stayed, and one drifted.

---

[MUSIC SWELL, then fade]

Now, here is what I want you to understand about Demas. He was not a casual observer. He was not a fringe member of the early church. In Philemon 1:24, Paul calls him a "fellow labourer." In Colossians 4:14, he is named right alongside Luke, the beloved physician. He was trusted. He was working. He was present.

And then — he was gone.

Paul's diagnosis of Demas is precise and painful. He says Demas loved "this present world." In the Greek, the word for "loved" is *agapēsas*. This is the same root word used in John 3:16 — *God so loved the world*. It is the word of the Great Commandment — *thou shalt love the Lord thy God*. It is the word Jesus used when He asked Peter three times on the shore: *"Lovest thou me?"*

Paul is saying that Demas took the deepest affection of his soul — the affection that belongs to God alone — and he gave it to the present age. He did not fear the world. He did not merely enjoy the world. He *loved* it.

Ellen White captures this tragedy in *The Acts of the Apostles*: *"For worldly gain, Demas bartered every high and noble consideration. How shortsighted the exchange!"*

---

[MUSIC TRANSITION]

But here is the question that makes this sermon so personal. How does a faithful laborer become a Demas?

It rarely happens with a dramatic announcement. It happens in the quiet spaces. It happens when urgency becomes background music — when the Second Coming stops feeling imminent and starts feeling theoretical. It happens when good work begins to replace first love — when we are so busy doing the work of the Lord that we forget the Lord of the work.

In Revelation 2, Jesus speaks to the church at Ephesus. He commends their hard work, their patience, their doctrinal purity. And then He says: *"Nevertheless I have somewhat against thee, because thou hast left thy first love."*

A church — a Christian professional — can work harder than anyone else and still have a cold heart. The most dangerous spiritual condition is not rebellion. It is comfortable productivity with a cold heart.

And then there is Luke. *"Only Luke is with me."* That word — *only* — is not a footnote. It is a pastoral testimony. One man's faithfulness became, in Paul's darkest hour, the entire presence of the body of Christ.

Luke was a physician. He had options. He could have found a safe, comfortable life far from a condemned prisoner. But he chose the prison cell. Why? Because his love for Christ remained intact. He wrote himself out of his own story — present in the "we" passages of Acts, but never inserting his name. He was not building his own brand. He was documenting Someone else's.

---

[PAUSE]

I want to be honest with you for a moment. I am a physician. I build things. I move fast. And sometimes, in the sheer volume of good work, I feel the pull. Not toward obvious sin. Toward something quieter. The satisfaction of a highly productive week that had very little room for the presence of God. The theology remains correct. The schedule remains full. But the heart has slowly moved.

That is the Demas condition. And if I am not careful, it is my condition.

We are all somewhere on this trajectory. The question is not whether we have felt the drift. The question is whether we are honest enough to stop and ask: What do I love most?

---

[SOFT MUSIC]

The good news — and there is always good news in the gospel — is that Christ does not leave us with a diagnosis alone. He leaves us with a prescription.

In Revelation 2:5, He speaks to the church at Ephesus — and to us: *"Remember therefore from whence thou art fallen, and repent, and do the first works."*

**Remember. Repent. Return.**

He does not say, "Work harder." He says, "Love Me first."

And as Ellen White writes in *Steps to Christ*: *"They behold the Saviour's matchless love… and to them duty becomes a delight and sacrifice a pleasure."*

This is the invitation. Not to more activity. To more love. To return to the One who never drifted from you.

---

[CLOSING]

Luke stayed. And so can you. Not in your own strength. Not by your own willpower. But in the strength of the One who stayed for you. Jesus Christ did not forsake you. He endured the cross, despising the shame, because of His great love for you.

Which man are you becoming? Demas, who loved the present age? Or Luke, who loved the present Christ?

Go, and love Him first.

Thank you for joining me today on Chukwuma Theology. If this message has spoken to you, share it with someone who needs to hear it. Until next time — be rooted in Scripture, and grounded in grace.

[OUTRO MUSIC — warm piano, fade out]

---
*Chukwuma Theology | Rooted in Scripture. Grounded in Grace.*
